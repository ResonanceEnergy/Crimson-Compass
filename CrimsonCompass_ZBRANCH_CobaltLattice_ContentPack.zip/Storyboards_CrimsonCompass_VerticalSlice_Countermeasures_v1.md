# Storyboards — Vertical Slice + Countermeasures (v1)

- A: Cold open + ZTECH loadout + first hypothesis
- B: Cobalt Lattice pressure beat (too-convenient lead → verify)
- C: On-the-run recovery (safe vs fast; containment dilemma)
