# Crimson Compass — One Drop Content Pack (ZBRANCH Countermeasures)

Includes:
- 40 countermeasure encounters (legacy+future)
- 15 player-set countermeasures
- 20 personal-layer countermeasures
- barks, UI template, selection rules, containment actions

Install:
- Use your ingestion pipeline to read JSONL/JSON.
