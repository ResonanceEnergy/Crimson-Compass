# Crimson Compass — Plug-and-Play Foundation (v1)

Contains the 10 pattern deck + lightweight schema.
Use patterns to stitch missions. Keep choices 3–5 and disproof exactly one.
